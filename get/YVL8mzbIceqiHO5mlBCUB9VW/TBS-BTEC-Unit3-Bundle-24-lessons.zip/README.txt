BTEC Unit 3 Personal and Business Finance: 24 lessons in 8 packs
For Pearson BTEC Level 3 National Extended Certificate in Business, Unit 3 Personal and Business Finance

U1: Pellwick Physio
U2: Sundersby Driving School
U3: Yarrowby Pet Grooming
U4: Hollinwick Brewing
U5: Ivelston Furniture
U6: Larkmoor Toys
U7: Bartholm Hair
U8: Dalverley Heating

Each pack: learner workbook and teacher guide, PDF and editable Word, full worked answers.
No slides in this version.

Licence: you may print, edit and use these files with the students you teach in your own school or college.
Please do not share the files publicly, upload them to another website, or resell them.

Honest limits: original fictional cases; indicative teaching guidance, not an exam board mark scheme;
no marks or grades; not endorsed by any exam board; lesson timings are estimates and have not been trialled in a classroom.

Questions or a problem with a file: reply to your Stripe receipt email, or write via thebusiness.school.
The Business School - thebusiness.school
