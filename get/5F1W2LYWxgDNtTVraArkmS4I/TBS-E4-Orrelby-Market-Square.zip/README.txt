Orrelby Market Square - 3 lessons for Pearson Edexcel A level Economics (9EC0), Theme 3 Business behaviour and the labour market

Files: student workbook and teacher guide, each as PDF and editable Word.

Licence: you may print, edit and use these files with the students you teach in your own school or college.
Please do not share the files publicly, upload them to another website, or resell them.

Honest limits: original fictional cases; indicative teaching guidance, not an exam board mark scheme;
no marks or grades; not endorsed by any exam board; lesson timings are estimates and have not been trialled in a classroom.

Questions or a problem with a file: reply to your Stripe receipt email, or write via thebusiness.school.
The Business School - thebusiness.school
