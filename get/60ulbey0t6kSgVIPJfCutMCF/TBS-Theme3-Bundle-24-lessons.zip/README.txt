Edexcel A level Business (9BS0), Theme 3: 24 lessons in 8 packs

B1: Harrowfield Linen
B2: Marrick Print
B3: Thistledown Garden Centre
B4: Calder Reach Building
B5: Skerrow Buses
B6: Tarnbeck Creamery
B7: Corvane Parcels
B8: Alderscar Furniture

Each pack: student workbook and teacher guide, PDF and editable Word, full worked answers.
No slides in this version.

Licence: you may print, edit and use these files with the students you teach in your own school or college.
Please do not share the files publicly, upload them to another website, or resell them.

Honest limits: original fictional cases; indicative teaching guidance, not an exam board mark scheme;
no marks or grades; not endorsed by any exam board; lesson timings are estimates and have not been trialled in a classroom.

Questions or a problem with a file: reply to your Stripe receipt email, or write via thebusiness.school.
The Business School - thebusiness.school
