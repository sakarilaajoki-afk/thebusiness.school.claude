Edexcel A level Economics (9EC0), Theme 3 Business behaviour and the labour market: 24 lessons in 8 packs

E1: Kettlebeck Guitars
E2: Wennick Ceramics
E3: Eskwith Glass
E4: Orrelby Market Square
E5: Garrowsay Fuel
E6: Merrowdale
E7: Sandrith Care Homes
E8: Quillmoor Fibre

Each pack: student workbook and teacher guide, PDF and editable Word, full worked answers.
No slides in this version.

Licence: you may print, edit and use these files with the students you teach in your own school or college.
Please do not share the files publicly, upload them to another website, or resell them.

Honest limits: original fictional cases; indicative teaching guidance, not an exam board mark scheme;
no marks or grades; not endorsed by any exam board; lesson timings are estimates and have not been trialled in a classroom.

Questions or a problem with a file: reply to your Stripe receipt email, or write via thebusiness.school.
The Business School - thebusiness.school
